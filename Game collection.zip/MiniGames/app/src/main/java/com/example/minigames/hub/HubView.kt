package com.example.minigames.hub

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import com.example.minigames.chess.KNIGHT
import com.example.minigames.chess.PieceArt
import com.example.minigames.core.BaseView
import com.example.minigames.core.Button
import com.example.minigames.core.GameId
import com.example.minigames.core.Host
import com.example.minigames.core.I18n
import com.example.minigames.core.OUTLINE
import com.example.minigames.core.W
import com.example.minigames.core.t
import com.example.minigames.core.withA
import kotlin.math.max
import kotlin.math.min

private class Card(
    val id: GameId,
    val titleKey: String,
    val top: Int,
    val bottom: Int,
    val button: Button
)

/** Home screen: one card per game, plus the global settings (language, sound, vibration). */
class HubView(context: Context, host: Host) : BaseView(context, host) {

    private enum class Page { HOME, SETTINGS }

    private var page = Page.HOME
    private val shaders = HashMap<Int, Shader>()

    private fun card(id: GameId, titleKey: String, cy: Float, top: Int, bottom: Int): Card {
        val b = btn({ "" }, W / 2f, cy, 400f, 92f) { leaveTo(id) }
        return Card(id, titleKey, top, bottom, b)
    }

    private val cards = listOf(
        card(GameId.FLAPPY, "flappy_title", 232f, Color.rgb(120, 214, 240), Color.rgb(48, 148, 204)),
        card(GameId.TTT, "ttt_title", 337f, Color.rgb(166, 150, 252), Color.rgb(90, 78, 204)),
        card(GameId.CHESS, "chess_title", 442f, Color.rgb(132, 208, 132), Color.rgb(48, 134, 84)),
        card(GameId.CHECKERS, "checkers_title", 547f, Color.rgb(248, 184, 96), Color.rgb(206, 108, 48))
    )

    private val settingsBtn = btn({ t("settings") }, W / 2f, 650f, 240f, 50f, style = { 1 }) { page = Page.SETTINGS }
    private val langQuick = btn({ I18n.codes[I18n.lang] }, W - 50f, 52f, 76f, 44f, style = { 1 }) {
        setLanguage((I18n.lang + 1) % I18n.codes.size)
    }

    // settings page
    private val langBtns: List<Button> = List(I18n.codes.size) { i ->
        btn(
            { I18n.names[i] }, 80f + i * 160f, 262f, 148f, 50f,
            style = { if (I18n.lang == i) 2 else 1 }
        ) { setLanguage(i) }
    }
    private val soundBtn = btn(
        { t("sound_x", if (sfx.enabled) t("on") else t("off")) }, W / 2f, 352f, 320f, 54f,
        style = { if (sfx.enabled) 2 else 3 }
    ) {
        sfx.enabled = !sfx.enabled
        store.soundOn = sfx.enabled
    }
    private val vibroBtn = btn(
        { t("vibration_x", if (store.haptics) t("on") else t("off")) }, W / 2f, 422f, 320f, 54f,
        style = { if (store.haptics) 2 else 3 }
    ) {
        store.haptics = !store.haptics
        haptic()
    }
    private val backBtn = btn({ t("back") }, W / 2f, 520f, 220f, 50f) { page = Page.HOME }

    private val homeButtons: List<Button> = cards.map { it.button } + listOf(settingsBtn, langQuick)
    private val settingsButtons: List<Button> = langBtns + listOf(soundBtn, vibroBtn, backBtn)

    override fun buttons(): List<Button> = if (page == Page.HOME) homeButtons else settingsButtons

    private fun setLanguage(i: Int) {
        I18n.lang = i
        store.lang = i
    }

    override fun onBack(): Boolean {
        if (fading) return true
        if (page == Page.SETTINGS) {
            page = Page.HOME
            return true
        }
        return false
    }

    // ------------------------------- update ---------------------------------

    override fun update() {
        updateClouds(0.12f)
    }

    // ------------------------------- drawing --------------------------------

    override fun draw(c: Canvas) {
        drawGradient(c, Color.rgb(70, 190, 210), Color.rgb(196, 236, 242))
        for (cl in clouds) drawCloud(c, cl, 0f)

        if (page == Page.HOME) drawHome(c) else drawSettings(c)
    }

    private fun drawHome(c: Canvas) {
        bobbingTitle(c, t("hub_title"), W / 2f, 128f, 60f, Color.rgb(255, 206, 60), 400f)
        for (card in cards) drawCard(c, card)
        drawButton(c, settingsBtn)
        drawButton(c, langQuick)
    }

    private fun drawSettings(c: Canvas) {
        text(c, t("settings"), W / 2f, 128f, 52f, Color.rgb(255, 206, 60), 10f, maxW = 400f)
        text(c, t("language"), W / 2f, 218f, 24f, Color.WHITE, 6f, maxW = 400f)
        for (b in settingsButtons) drawButton(c, b)
    }

    private fun stats(id: GameId): String = when (id) {
        GameId.FLAPPY -> {
            val best = listOf("EASY", "NORMAL", "HARD").maxOf { store.getI("flappy_best_$it", 0) }
            t("best_x", best)
        }
        GameId.TTT -> short("ttt")
        GameId.CHESS -> short("chess")
        else -> short("checkers")
    }

    private fun short(key: String): String =
        t("stats_short", store.stat(key, 0), store.stat(key, 1), store.stat(key, 2))

    private fun drawCard(c: Canvas, card: Card) {
        val b = card.button
        val press = max(b.down, b.press)
        val sc = 1f - 0.04f * b.down
        val l = -b.w / 2f
        val tp = -b.h / 2f
        val r = b.w / 2f
        val bt = b.h / 2f

        c.save()
        c.translate(b.cx, b.cy + 4f * press)
        c.scale(sc, sc)

        fillRRect(c, l, tp + 6f - 4f * press, r, bt + 6f - 4f * press, 24f, OUTLINE)
        val sh = shaders.getOrPut(card.id.ordinal) {
            LinearGradient(0f, tp, 0f, bt, card.top, card.bottom, Shader.TileMode.CLAMP)
        }
        fill.shader = sh
        fill.color = Color.WHITE
        rf.set(l, tp, r, bt)
        c.drawRoundRect(rf, 24f, 24f, fill)
        fill.shader = null
        fillRRect(c, l + 8f, tp + 6f, r - 8f, tp + b.h * 0.45f, 16f, withA(Color.WHITE, 0.22f + 0.15f * b.down))
        strokeRRect(c, l, tp, r, bt, 24f, OUTLINE, 4f)

        // icon medallion
        val ix = l + 58f
        fillOval(c, ix - 38f, -38f, ix + 38f, 38f, withA(Color.WHITE, 0.3f))
        strokeOval(c, ix - 38f, -38f, ix + 38f, 38f, OUTLINE, 3f)
        drawIcon(c, card.id, ix, 0f)

        // texts (left aligned)
        val left = l + 112f
        val title = t(card.titleKey)
        val tw = min(measure(title, 30f), 268f)
        text(c, title, left + tw / 2f, -4f, 30f, Color.WHITE, 7f, OUTLINE, 268f)
        plainText(c, stats(card.id), left, 28f, 17f, withA(Color.WHITE, 0.95f), -1, 268f)
        c.restore()
    }

    private fun drawIcon(c: Canvas, id: GameId, x: Float, y: Float) {
        when (id) {
            GameId.FLAPPY -> {
                val s = 1.05f
                fillOval(c, x - 19f * s, y - 14f * s, x + 19f * s, y + 14f * s, Color.rgb(250, 198, 50))
                strokeOval(c, x - 19f * s, y - 14f * s, x + 19f * s, y + 14f * s, OUTLINE, 2.4f)
                fillOval(c, x - 13f * s, y - 1f * s, x + 4f * s, y + 9f * s, Color.rgb(255, 250, 235))
                strokeOval(c, x - 13f * s, y - 1f * s, x + 4f * s, y + 9f * s, OUTLINE, 2f)
                fillOval(c, x + 2f * s, y - 12f * s, x + 14f * s, y, Color.WHITE)
                strokeOval(c, x + 2f * s, y - 12f * s, x + 14f * s, y, OUTLINE, 2f)
                fillOval(c, x + 8f * s, y - 8f * s, x + 12f * s, y - 3f * s, OUTLINE)
                fillRRect(c, x + 14f * s, y - 2f * s, x + 28f * s, y + 6f * s, 3f, Color.rgb(255, 120, 45))
                strokeRRect(c, x + 14f * s, y - 2f * s, x + 28f * s, y + 6f * s, 3f, OUTLINE, 2f)
            }
            GameId.TTT -> {
                line.color = Color.rgb(232, 84, 72)
                line.strokeWidth = 6f
                c.drawLine(x - 26f, y - 12f, x - 6f, y + 8f, line)
                c.drawLine(x - 6f, y - 12f, x - 26f, y + 8f, line)
                line.color = Color.rgb(250, 250, 255)
                c.drawCircle(x + 14f, y + 2f, 11f, line)
            }
            GameId.CHESS -> PieceArt.draw(c, KNIGHT, true, x, y - 1f, 66f)
            else -> {
                disc(c, x - 10f, y + 8f, true)
                disc(c, x + 10f, y - 8f, false)
            }
        }
    }

    private fun disc(c: Canvas, x: Float, y: Float, white: Boolean) {
        val base = if (white) Color.rgb(250, 244, 232) else Color.rgb(78, 66, 86)
        val ring = if (white) Color.rgb(196, 182, 160) else Color.rgb(36, 28, 42)
        fillOval(c, x - 17f, y - 17f, x + 17f, y + 17f, base)
        strokeOval(c, x - 17f, y - 17f, x + 17f, y + 17f, ring, 3f)
        strokeOval(c, x - 11f, y - 11f, x + 11f, y + 11f, ring, 2f)
    }
}
